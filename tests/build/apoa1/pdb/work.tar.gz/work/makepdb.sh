#!/bin/sh

grep PRO1 ./PDB/apoa1.pdb > pro1.pdb
grep PRO2 ./PDB/apoa1.pdb > pro2.pdb
grep LIP1 ./PDB/apoa1.pdb > lip1.pdb
grep LIP2 ./PDB/apoa1.pdb > lip2.pdb
grep WAT1 ./PDB/apoa1.pdb > wat1.pdb
grep WAT2 ./PDB/apoa1.pdb > wat2.pdb
grep WAT3 ./PDB/apoa1.pdb > wat3.pdb
grep WAT4 ./PDB/apoa1.pdb > wat4.pdb
grep WAT5 ./PDB/apoa1.pdb > wat5.pdb
grep WAT6 ./PDB/apoa1.pdb > wat6.pdb
grep WAT7 ./PDB/apoa1.pdb > wat7.pdb
grep WAT8 ./PDB/apoa1.pdb > wat8.pdb
grep WAT9 ./PDB/apoa1.pdb > wat9.pdb

sed -f popc1.sed lip1.pdb > lip1_rn1.pdb
sed -f popc1.sed lip2.pdb > lip2_rn1.pdb
sed -f popc2.sed lip1_rn1.pdb > lip1_rn2.pdb
sed -f popc2.sed lip2_rn1.pdb > lip2_rn2.pdb

convpdb.pl -renumber 48 -segnames pro1.pdb > pro1_s.pdb
convpdb.pl -renumber 48 -segnames pro2.pdb > pro2_s.pdb
convpdb.pl -renumber 1  -segnames lip1_rn2.pdb > lip1_s.pdb
convpdb.pl -renumber 1  -segnames lip2_rn2.pdb > lip2_s.pdb
convpdb.pl -renumber 1  -segnames wat1.pdb > wat1_s.pdb
convpdb.pl -renumber 1  -segnames wat2.pdb > wat2_s.pdb
convpdb.pl -renumber 1  -segnames wat3.pdb > wat3_s.pdb
convpdb.pl -renumber 1  -segnames wat4.pdb > wat4_s.pdb
convpdb.pl -renumber 1  -segnames wat5.pdb > wat5_s.pdb
convpdb.pl -renumber 1  -segnames wat6.pdb > wat6_s.pdb
convpdb.pl -renumber 1  -segnames wat7.pdb > wat7_s.pdb
convpdb.pl -renumber 1  -segnames wat8.pdb > wat8_s.pdb
convpdb.pl -renumber 1  -segnames wat9.pdb > wat9_s.pdb

sed 's/PRO0/PRO1/g' pro1_s.pdb > ../pro1_s.pdb
sed 's/PRO0/PRO2/g' pro2_s.pdb > ../pro2_s.pdb
sed 's/PRO0/LIP1/g' lip1_s.pdb > ../lip1_s.pdb
sed 's/PRO0/LIP2/g' lip2_s.pdb > ../lip2_s.pdb
sed 's/WT00/WAT1/g' wat1_s.pdb > ../wat1_s.pdb
sed 's/WT00/WAT2/g' wat2_s.pdb > ../wat2_s.pdb
sed 's/WT00/WAT3/g' wat3_s.pdb > ../wat3_s.pdb
sed 's/WT00/WAT4/g' wat4_s.pdb > ../wat4_s.pdb
sed 's/WT00/WAT5/g' wat5_s.pdb > ../wat5_s.pdb
sed 's/WT00/WAT6/g' wat6_s.pdb > ../wat6_s.pdb
sed 's/WT00/WAT7/g' wat7_s.pdb > ../wat7_s.pdb
sed 's/WT00/WAT8/g' wat8_s.pdb > ../wat8_s.pdb
sed 's/WT00/WAT9/g' wat9_s.pdb > ../wat9_s.pdb

