#!/bin/sh
 convpdb.pl -renumber 1 -segnames ./pdb/AEMP.pdb  > AEMP.pdb
 sed 's/PRO0/AEMP/g' < AEMP.pdb > AEMP_s.pdb
 convpdb.pl -renumber 1 -segnames ./pdb/ATPA.pdb  > ATPA.pdb
 sed 's/PRO0/ATPA/g' < ATPA.pdb > ATPA_s.pdb
 convpdb.pl -renumber 1 -segnames ./pdb/AATP.pdb  > AATP.pdb
 sed 's/PRO0/AATP/g' < AATP.pdb > AATP_s.pdb
 convpdb.pl -renumber 1 -segnames ./pdb/ATPB.pdb  > ATPB.pdb
 sed 's/PRO0/ATPB/g' < ATPB.pdb > ATPB_s.pdb
 convpdb.pl -renumber 1 -segnames ./pdb/AADP.pdb  > AADP.pdb
 sed 's/PRO0/AADP/g' < AADP.pdb > AADP_s.pdb
 convpdb.pl -renumber 1 -segnames ./pdb/ATPC.pdb  > ATPC.pdb
 sed 's/PRO0/ATPC/g' < ATPC.pdb > ATPC_s.pdb
 convpdb.pl -renumber 1 -segnames ./pdb/BADP.pdb  > BADP.pdb
 sed 's/PRO0/BADP/g' < BADP.pdb > BADP_s.pdb
 convpdb.pl -renumber 1 -segnames ./pdb/ADPD.pdb  > ADPD.pdb
 sed 's/PRO0/ADPD/g' < ADPD.pdb > ADPD_s.pdb
 convpdb.pl -renumber 1 -segnames ./pdb/BEMP.pdb  > BEMP.pdb
 sed 's/PRO0/BEMP/g' < BEMP.pdb > BEMP_s.pdb
 convpdb.pl -renumber 1 -segnames ./pdb/BATP.pdb  > BATP.pdb
 sed 's/PRO0/BATP/g' < BATP.pdb > BATP_s.pdb
 convpdb.pl -renumber 1 -segnames ./pdb/ATPF.pdb  > ATPF.pdb
 sed 's/PRO0/ATPF/g' < ATPF.pdb > ATPF_s.pdb
 convpdb.pl -renumber 1 -segnames ./pdb/GAMA.pdb  > GAMA.pdb
 sed 's/PRO0/GAMA/g' < GAMA.pdb > GAMA_s.pdb
 convpdb.pl -renumber 1 -segnames ./pdb/DLTA.pdb  > DLTA.pdb
 sed 's/PRO0/DLTA/g' < DLTA.pdb > DLTA_s.pdb
 convpdb.pl -renumber 1 -segnames ./pdb/PSLN.pdb  > PSLN.pdb
 sed 's/PRO0/PSLN/g' < PSLN.pdb > PSLN_s.pdb
 convpdb.pl -renumber 1 -segnames ./pdb/RWAT.pdb  > RWAT.pdb
 sed 's/WT00/RWAT/g' < RWAT.pdb > RWAT_s.pdb
 convpdb.pl -renumber 1 -segnames ./pdb/SWAT.pdb  > SWAT.pdb
 sed 's/WT00/SWAT/g' < SWAT.pdb > SWAT_s.pdb
 convpdb.pl -renumber 1 -segnames ./pdb/TWAT.pdb  > TWAT.pdb
 sed 's/WT00/TWAT/g' < TWAT.pdb > TWAT_s.pdb
 convpdb.pl -renumber 1 -segnames ./pdb/UWAT.pdb  > UWAT.pdb
 sed 's/WT00/UWAT/g' < UWAT.pdb > UWAT_s.pdb
 convpdb.pl -renumber 1 -segnames ./pdb/VWAT.pdb  > VWAT.pdb
 sed 's/WT00/VWAT/g' < VWAT.pdb > VWAT_s.pdb
 convpdb.pl -renumber 1 -segnames ./pdb/WWAT.pdb  > WWAT.pdb
 sed 's/WT00/WWAT/g' < WWAT.pdb > WWAT_s.pdb
 convpdb.pl -renumber 1 -segnames ./pdb/XWAT.pdb  > XWAT.pdb
 sed 's/WT00/XWAT/g' < XWAT.pdb > XWAT_s.pdb
 convpdb.pl -renumber 1 -segnames ./pdb/YWAT.pdb  > YWAT.pdb
 sed 's/WT00/YWAT/g' < YWAT.pdb > YWAT_s.pdb
 convpdb.pl -renumber 1 -segnames ./pdb/ZWAT.pdb  > ZWAT.pdb
 sed 's/WT00/ZWAT/g' < ZWAT.pdb > ZWAT_s.pdb
 convpdb.pl -renumber 1 -segnames ./pdb/DWAT.pdb  > DWAT.pdb
 sed 's/WT00/DWAT/g' < DWAT.pdb > DWAT_s.pdb
 convpdb.pl -renumber 1 -segnames ./pdb/WS1.pdb  > WS1.pdb
 sed 's/WT00/WS1 /g' < WS1.pdb > WS1_s.pdb
 convpdb.pl -renumber 1 -segnames ./pdb/WS2.pdb  > WS2.pdb
 sed 's/WT00/WS2 /g' < WS2.pdb > WS2_s.pdb
 convpdb.pl -renumber 1 -segnames ./pdb/WS3.pdb  > WS3.pdb
 sed 's/WT00/WS3 /g' < WS3.pdb > WS3_s.pdb
 convpdb.pl -renumber 1 -segnames ./pdb/WS4.pdb  > WS4.pdb
 sed 's/WT00/WS4 /g' < WS4.pdb > WS4_s.pdb
 convpdb.pl -renumber 1 -segnames ./pdb/WS5.pdb  > WS5.pdb
 sed 's/WT00/WS5 /g' < WS5.pdb > WS5_s.pdb
 convpdb.pl -renumber 1 -segnames ./pdb/WS6.pdb  > WS6.pdb
 sed 's/WT00/WS6 /g' < WS6.pdb > WS6_s.pdb
 convpdb.pl -renumber 1 -segnames ./pdb/WS7.pdb  > WS7.pdb
 sed 's/WT00/WS7 /g' < WS7.pdb > WS7_s.pdb
 convpdb.pl -renumber 1 -segnames ./pdb/WS8.pdb  > WS8.pdb
 sed 's/WT00/WS8 /g' < WS8.pdb > WS8_s.pdb
 convpdb.pl -renumber 1 -segnames ./pdb/WS9.pdb  > WS9.pdb
 sed 's/WT00/WS9 /g' < WS9.pdb > WS9_s.pdb
 convpdb.pl -renumber 1 -segnames ./pdb/WS10.pdb  > WS10.pdb
 sed 's/WT00/WS10/g' < WS10.pdb > WS10_s.pdb
 convpdb.pl -renumber 1 -segnames ./pdb/WS11.pdb  > WS11.pdb
 sed 's/WT00/WS11/g' < WS11.pdb > WS11_s.pdb
 convpdb.pl -renumber 1 -segnames ./pdb/WS12.pdb  > WS12.pdb
 sed 's/WT00/WS12/g' < WS12.pdb > WS12_s.pdb
 convpdb.pl -renumber 1 -segnames ./pdb/SOD.pdb  > SOD.pdb
 sed 's/PRO0/SOD /g' < SOD.pdb > SOD_s.pdb
 convpdb.pl -renumber 1 -segnames ./pdb/CHL.pdb  > CHL.pdb
 sed 's/PRO0/CHL /g' < CHL.pdb > CHL_s.pdb
