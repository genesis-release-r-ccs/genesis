#!/bin/sh

 grep AEMP ../data/f1wations_xplor.pdb > AEMP.pdb
 grep ATPA ../data/f1wations_xplor.pdb > ATPA.pdb
 grep AATP ../data/f1wations_xplor.pdb > AATP.pdb
 grep ATPB ../data/f1wations_xplor.pdb > ATPB.pdb
 grep AADP ../data/f1wations_xplor.pdb > AADP.pdb
 grep ATPC ../data/f1wations_xplor.pdb > ATPC.pdb
 grep BADP ../data/f1wations_xplor.pdb > BADP.pdb
 grep ADPD ../data/f1wations_xplor.pdb > ADPD.pdb
 grep BEMP ../data/f1wations_xplor.pdb > BEMP.pdb
 grep BATP ../data/f1wations_xplor.pdb > BATP.pdb
 grep ATPF ../data/f1wations_xplor.pdb > ATPF.pdb
 grep GAMA ../data/f1wations_xplor.pdb > GAMA.pdb
 grep DLTA ../data/f1wations_xplor.pdb > DLTA.pdb
 grep PSLN ../data/f1wations_xplor.pdb > PSLN.pdb
 grep RWAT ../data/f1wations_xplor.pdb > RWAT.pdb
 grep SWAT ../data/f1wations_xplor.pdb > SWAT.pdb
 grep TWAT ../data/f1wations_xplor.pdb > TWAT.pdb
 grep UWAT ../data/f1wations_xplor.pdb > UWAT.pdb
 grep VWAT ../data/f1wations_xplor.pdb > VWAT.pdb
 grep WWAT ../data/f1wations_xplor.pdb > WWAT.pdb
 grep XWAT ../data/f1wations_xplor.pdb > XWAT.pdb
 grep YWAT ../data/f1wations_xplor.pdb > YWAT.pdb
 grep ZWAT ../data/f1wations_xplor.pdb > ZWAT.pdb
 grep DWAT ../data/f1wations_xplor.pdb > DWAT.pdb
 grep 'WS1 ' ../data/f1wations_xplor.pdb > WS1.pdb
 grep 'WS2 ' ../data/f1wations_xplor.pdb > WS2.pdb
 grep 'WS3 ' ../data/f1wations_xplor.pdb > WS3.pdb
 grep 'WS4 ' ../data/f1wations_xplor.pdb > WS4.pdb
 grep 'WS5 ' ../data/f1wations_xplor.pdb > WS5.pdb
 grep 'WS6 ' ../data/f1wations_xplor.pdb > WS6.pdb
 grep 'WS7 ' ../data/f1wations_xplor.pdb > WS7.pdb
 grep 'WS8 ' ../data/f1wations_xplor.pdb > WS8.pdb
 grep 'WS9 ' ../data/f1wations_xplor.pdb > WS9.pdb
 grep 'WS10' ../data/f1wations_xplor.pdb > WS10.pdb
 grep 'WS11' ../data/f1wations_xplor.pdb > WS11.pdb
 grep 'WS12' ../data/f1wations_xplor.pdb > WS12.pdb
 grep 'SOD ' ../data/f1wations_xplor.pdb > SOD.pdb
 grep 'CHL ' ../data/f1wations_xplor.pdb > CHL.pdb

