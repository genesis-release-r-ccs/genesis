#!/bin/sh

grep 5DFR ./PDB/5dhfr_cube.pdb > PRO0.pdb
grep WAT  ./PDB/5dhfr_cube.pdb > WT00.pdb

convpdb.pl -renumber 1 -segnames PRO0.pdb > pro0_s.pdb
convpdb.pl -renumber 1 -segnames WT00.pdb > wt00_s.pdb

sed 's/PRO0/PRO1/g' pro0_s.pdb > ../pro1_s.pdb
sed 's/WT00/WAT1/g' wt00_s.pdb > ../wat1_s.pdb

